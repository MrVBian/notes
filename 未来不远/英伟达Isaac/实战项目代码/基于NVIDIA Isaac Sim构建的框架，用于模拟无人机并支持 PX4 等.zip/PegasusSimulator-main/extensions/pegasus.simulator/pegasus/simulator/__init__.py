"""
| Author: Marcelo Jacinto (marcelo.jacinto@tecnico.ulisboa.pt)
| License: BSD-3-Clause. Copyright (c) 2023, Marcelo Jacinto. All rights reserved.
"""

__author__ = "Marcelo Jacinto"
__email__ = "marcelo.jacinto@tecnico.ulisboa.pt"

from .extension import Pegasus_SimulatorExtension