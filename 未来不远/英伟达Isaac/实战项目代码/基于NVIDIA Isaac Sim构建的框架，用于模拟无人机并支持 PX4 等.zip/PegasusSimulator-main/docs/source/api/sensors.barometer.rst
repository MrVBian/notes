Barometer
=========

This sensor follows the International Standard Atmosphere (ISA) model :cite:p:`baromter_implementation` .

.. automodule:: pegasus.simulator.logic.sensors.barometer
   :members:
   :undoc-members:
   :show-inheritance:
