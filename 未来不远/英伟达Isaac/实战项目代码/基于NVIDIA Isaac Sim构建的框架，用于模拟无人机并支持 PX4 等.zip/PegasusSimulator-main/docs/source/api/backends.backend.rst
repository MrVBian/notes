Backend
=======

.. automodule:: pegasus.simulator.logic.backends.backend
   :members:
   :undoc-members:
   :show-inheritance:
