Vehicle Manager
===============

.. automodule:: pegasus.simulator.logic.vehicle_manager
   :members:
   :undoc-members:
   :show-inheritance: