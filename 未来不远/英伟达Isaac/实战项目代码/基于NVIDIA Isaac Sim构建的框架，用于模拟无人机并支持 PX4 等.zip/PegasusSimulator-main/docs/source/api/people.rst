People
======

.. automodule:: pegasus.simulator.logic.people.person
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: pegasus.simulator.logic.people.person_controller
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: pegasus.simulator.logic.people_manager
   :members:
   :undoc-members:
   :show-inheritance: