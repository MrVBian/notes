Quadratic Thrust Curve
======================

.. automodule:: pegasus.simulator.logic.thrusters.quadratic_thrust_curve
   :members:
   :undoc-members:
   :show-inheritance: