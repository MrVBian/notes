﻿omni.isaac.lab.scene
====================

.. automodule:: omni.isaac.lab.scene

  .. rubric:: Classes

  .. autosummary::

    InteractiveScene
    InteractiveSceneCfg

interactive Scene
-----------------

.. autoclass:: InteractiveScene
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: InteractiveSceneCfg
    :members:
    :exclude-members: __init__
