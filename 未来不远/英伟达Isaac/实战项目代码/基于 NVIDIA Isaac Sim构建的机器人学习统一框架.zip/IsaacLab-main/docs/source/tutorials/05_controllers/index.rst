Using Motion Generators
=======================

While the robots in the simulation environment can be controlled at the joint-level, the following
tutorials show you how to use motion generators to control the robots at the task-level.

.. toctree::
    :maxdepth: 1
    :titlesonly:

    run_diff_ik
